Liberation Mono for Powerline
=============================

:Font creator: Steve Mattesen
:Version: 2.00.1
:Source: https://fedorahosted.org/liberation-fonts/
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Dan Savilonis <https://github.com/djs>`_

