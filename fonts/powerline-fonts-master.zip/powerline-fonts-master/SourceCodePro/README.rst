Source Code Pro for Powerline
=============================

:Font creator: Paul D. Hunt (Adobe)
:Version: 1.017
:Source: http://sourceforge.net/projects/sourcecodepro.adobe/
:License: SIL OPEN FONT LICENSE Version 1.1
:Patched by: `Sven Strothoff <https://github.com/sven-strothoff>`_
