Anonymous Pro for Powerline
===========================

:Font creator: Mark Simonson
:Source: http://www.marksimonson.com/fonts/view/anonymous-pro
:Patched by: `Ryan Souza <https://github.com/ryansouza>`_
